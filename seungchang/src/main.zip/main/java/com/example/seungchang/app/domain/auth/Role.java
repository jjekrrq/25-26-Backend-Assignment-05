package com.example.seungchang.app.domain.auth;

public enum Role {
    USER,
    ADMIN
}
