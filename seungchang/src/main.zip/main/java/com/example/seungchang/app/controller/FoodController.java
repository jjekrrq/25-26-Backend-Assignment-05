package com.example.seungchang.app.controller;

public class FoodController {
}
